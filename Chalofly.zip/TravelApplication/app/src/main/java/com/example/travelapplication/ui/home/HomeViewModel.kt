package com.example.travelapplication.ui.home

import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel() : ViewModel() {

    private val _selectedFragment = MutableLiveData<Class<out Fragment>>()
    val selectedFragment: LiveData<Class<out Fragment>> get() = _selectedFragment

    fun selectFragment(fragmentClass: Class<out Fragment>) {
        _selectedFragment.value = fragmentClass
    }

}