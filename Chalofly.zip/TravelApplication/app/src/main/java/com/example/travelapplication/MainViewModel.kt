package com.example.travelapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel:ViewModel() {
    private val _selectedItem = MutableLiveData<Int>()
    val selectedItem: LiveData<Int> get() = _selectedItem

    fun selectItem(itemId: Int) {
        _selectedItem.value = itemId
    }
}