package com.example.travelapplication.ui.profile.sharetheapp

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
enum class NavigationEvent {
    SUPPORT, MANAGE_ACCOUNT, SHARED_APP, GIFT_CARD,ABOUT_CHALOFLY,SIGN_OUT
}


class SharedViewModel : ViewModel() {
    private val _navigationEvent = MutableLiveData<NavigationEvent?>()
    val navigationEvent: LiveData<NavigationEvent?> get() = _navigationEvent

    fun onNavigateTo(event: NavigationEvent) {
        _navigationEvent.value = event
    }

    fun onNavigationCompleted() {
        _navigationEvent.value = null
    }
}