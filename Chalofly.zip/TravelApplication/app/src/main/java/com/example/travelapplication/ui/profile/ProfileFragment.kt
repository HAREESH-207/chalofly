package com.example.travelapplication.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.commit
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.travelapplication.R
import com.example.travelapplication.databinding.FragmentProfileBinding
import com.example.travelapplication.databinding.FragmentProfileBinding.*
import com.example.travelapplication.ui.profile.giftcard.GiftCardFragment
import com.example.travelapplication.ui.profile.manageaccount.ManageAccountFragment
import com.example.travelapplication.ui.profile.sharetheapp.NavigationEvent
import com.example.travelapplication.ui.profile.sharetheapp.ShareFragment
import com.example.travelapplication.ui.profile.sharetheapp.SharedViewModel
import com.example.travelapplication.ui.profile.signout.SignOutFragment
import com.example.travelapplication.ui.profile.support.SupportFragment

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null

    private val sharedViewModel: SharedViewModel by activityViewModels()
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val profileViewModel =
            ViewModelProvider(this).get(ProfileViewModel::class.java)

        _binding = inflate(inflater, container, false)
        val root: View = binding.root
        binding.textSupport.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.SUPPORT)
        }
        binding.textManageAccount.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.MANAGE_ACCOUNT)
        }
        binding.textGiftCard.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.GIFT_CARD)
        }
        binding.textSharedApp.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.SHARED_APP)
        }
        binding.textAboutChalofly.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.ABOUT_CHALOFLY)
        }
        binding.textSignOut.setOnClickListener {
            sharedViewModel.onNavigateTo(NavigationEvent.SIGN_OUT)
        }


        return root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel.navigationEvent.observe(viewLifecycleOwner, Observer { event ->
            event?.let {
                when (it) {
                    NavigationEvent.SUPPORT -> navigateToFragment(SupportFragment())
                    NavigationEvent.MANAGE_ACCOUNT -> navigateToFragment(ManageAccountFragment())
                    NavigationEvent.GIFT_CARD -> navigateToFragment(GiftCardFragment())
                    NavigationEvent.SHARED_APP -> navigateToFragment(ShareFragment())
                    NavigationEvent.SIGN_OUT -> navigateToFragment(SignOutFragment())
                    NavigationEvent.ABOUT_CHALOFLY -> navigateToFragment(SignOutFragment())
                }
                sharedViewModel.onNavigationCompleted()
            }
        })
    }

    private fun navigateToFragment(fragment: Fragment) {
        parentFragmentManager.commit {
            replace(R.id.fragment_container, fragment)
            addToBackStack(null)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}