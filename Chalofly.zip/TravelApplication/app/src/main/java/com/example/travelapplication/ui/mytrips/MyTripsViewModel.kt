package com.example.travelapplication.ui.mytrips

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MyTripsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is myTrips Fragment"
    }

    val text: LiveData<String> = _text
}