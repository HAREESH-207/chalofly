package com.example.travelapplication.ui.mytrips

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.travelapplication.databinding.FragmentMyTripsBinding
import com.example.travelapplication.ui.cart.CartViewModel


class MyTripsFragment : Fragment() {

    private var _binding: FragmentMyTripsBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val myTripsViewModel =
            ViewModelProvider(this).get(MyTripsViewModel::class.java)
        _binding = FragmentMyTripsBinding.inflate(inflater, container, false)
        val root: View = binding.root


        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}