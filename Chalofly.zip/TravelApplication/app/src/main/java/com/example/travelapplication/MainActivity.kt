package com.example.travelapplication

import android.os.Bundle
import androidx.activity.viewModels
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.travelapplication.databinding.ActivityMainBinding
import com.example.travelapplication.ui.cart.CartFragment
import com.example.travelapplication.ui.coupons.CouponFragment
import com.example.travelapplication.ui.home.HomeFragment
import com.example.travelapplication.ui.mytrips.MyTripsFragment
import com.example.travelapplication.ui.profile.ProfileFragment

class MainActivity : AppCompatActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            mainViewModel.selectItem(item.itemId)
            true

        }

        mainViewModel.selectedItem.observe(this, Observer { itemId ->
            val selectedFragment: Fragment = when (itemId) {
                R.id.navigation_home -> HomeFragment()
                R.id.navigation_my_trips -> MyTripsFragment()
                R.id.navigation_coupons -> CouponFragment()
                R.id.navigation_cart -> CartFragment()
                R.id.navigation_profile -> ProfileFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, selectedFragment)
                .commit()
        })

        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.navigation_home
        }
    }
}