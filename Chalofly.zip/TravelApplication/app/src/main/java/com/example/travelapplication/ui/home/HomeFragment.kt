package com.example.travelapplication.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.example.travelapplication.R
import com.example.travelapplication.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.selectFragment(FlightsFragment::class.java)

        binding.textFlights.setOnClickListener {
            viewModel.selectFragment(FlightsFragment::class.java)
        }

        binding.textBuses.setOnClickListener {
            viewModel.selectFragment(BusesFragment::class.java)
        }

        binding.textGroup.setOnClickListener {
     //       viewModel.selectFragment(GroupsFragment::class.java)
        }

        binding.textHolidays.setOnClickListener {
            viewModel.selectFragment(HolidaysFragment::class.java)
        }

        binding.textOffers.setOnClickListener {
            viewModel.selectFragment(OffersFragment::class.java)
        }

        viewModel.selectedFragment.observe(viewLifecycleOwner, Observer { fragmentClass ->
            fragmentClass?.let {
                replaceFragment(it)
            }
        })
    }

    private fun replaceFragment(fragmentClass: Class<out Fragment>) {
        val fragment = fragmentClass.newInstance()
        parentFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}