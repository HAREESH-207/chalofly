package com.example.travelapplication.ui.coupons

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import com.example.travelapplication.R
import com.example.travelapplication.databinding.FragmentCartBinding
import com.example.travelapplication.databinding.FragmentCouponBinding
import com.example.travelapplication.ui.cart.CartViewModel

class CouponFragment : Fragment() {

    private var _binding: FragmentCouponBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val couponViewModel =
            ViewModelProvider(this).get(CouponViewModel::class.java)

        _binding = FragmentCouponBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textCoupon
        couponViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}