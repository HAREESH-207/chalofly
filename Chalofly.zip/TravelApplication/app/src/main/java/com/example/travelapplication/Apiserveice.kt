package com.example.travelapplication

interface Apiserveice {

}