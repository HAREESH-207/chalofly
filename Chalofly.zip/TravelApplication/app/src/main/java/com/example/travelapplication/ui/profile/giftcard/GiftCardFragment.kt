package com.example.travelapplication.ui.profile.giftcard

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.example.travelapplication.R
import com.example.travelapplication.databinding.FragmentGiftCardBinding
import com.example.travelapplication.databinding.FragmentMyTripsBinding
import com.example.travelapplication.ui.mytrips.MyTripsViewModel


class GiftCardFragment : Fragment() {
    private var _binding: FragmentGiftCardBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGiftCardBinding.inflate(inflater, container, false)
        val root: View = binding.root


        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}